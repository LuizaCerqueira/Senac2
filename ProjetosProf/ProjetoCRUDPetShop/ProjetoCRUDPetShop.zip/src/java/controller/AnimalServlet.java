package controller;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Animal;
import model.DaoAnimal;

/**
 *
 * @author ricardo.amaral
 */
@WebServlet(name = "AnimalServlet", urlPatterns = {"/AnimalServlet"})
public class AnimalServlet extends HttpServlet {

    private DaoAnimal daoAnimal = new DaoAnimal();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String nomeAnimal = request.getParameter("nomeAnimal");
        String dono = request.getParameter("dono");
        String especie = request.getParameter("especie");
        String raca = request.getParameter("raca");
        String sexo = request.getParameter("sexo");
        int idade = Integer.parseInt(request.getParameter("idade"));
        
        String msg = "";
        
        try{
            Animal animal = new Animal();
            animal.setNomeAnimal(nomeAnimal);
            animal.setNomeDono(dono);
            animal.setEspecie(especie);
            animal.setRaca(raca);
            animal.setSexo(sexo);
            animal.setIdade(idade);
            msg = daoAnimal.inserirAnimal(animal);
            /*
            if(resp == true){
                msg = "<h3 style='color: green'>Dados cadastrados com sucesso.</h3>";
            }else{
                msg = "<h3 style='color: red'>Erro ao cadastrar.</h3>";
            }*/
            RequestDispatcher rd = request.getRequestDispatcher("CadastroAnimal.jsp");
            request.setAttribute("mensagem", msg);
            request.setAttribute("animais", daoAnimal.pesquisarAnimais());
            rd.forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
