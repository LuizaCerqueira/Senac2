package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import sql.ConectaBD;

public class DaoAnimal {

    private Connection conn;

    public DaoAnimal() {
        conn = ConectaBD.getConnection();
    }

    //método para inserir dados na tabela animal
    public String inserirAnimal(Animal animal) {
        String msg = "";
        try {
            String sql = "insert into animal values "
                    + "(null,?,?,?,?,?,?)";
            PreparedStatement inserir = conn.prepareStatement(sql);
            inserir.setString(1, animal.getNomeAnimal());
            inserir.setString(2, animal.getNomeDono());
            inserir.setString(3, animal.getEspecie());
            inserir.setString(4, animal.getRaca());
            inserir.setString(5, animal.getSexo());
            inserir.setInt(6, animal.getIdade());
            inserir.execute();
            msg = "<h3 style='color: green'>Dados cadastrados com sucesso.</h3>";
            return msg;
        } catch (Exception e) {
            msg = e.toString();
            return msg;
        }
    }

    public List<Animal> pesquisarAnimais() throws Exception {
        List<Animal> lista = new ArrayList<Animal>();
        String sql = "select * from animal";
        PreparedStatement pesquisa = conn.prepareStatement(sql);
        ResultSet rs = pesquisa.executeQuery();
        while (rs.next()) {
            Animal animal = new Animal();
            animal.setCodigo(rs.getInt("codigo"));
            animal.setNomeAnimal(rs.getString("nomeAnimal"));
            animal.setNomeDono(rs.getString("nomeDono"));
            animal.setEspecie(rs.getString("especie"));
            animal.setRaca(rs.getString("raca"));
            animal.setSexo(rs.getString("sexo"));
            animal.setIdade(rs.getInt("idade"));
            lista.add(animal);
        }
        return lista;
    }
}
